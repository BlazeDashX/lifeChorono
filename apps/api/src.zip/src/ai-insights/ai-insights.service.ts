import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { GoogleGenerativeAI } from '@google/generative-ai';

@Injectable()
export class AiInsightsService {
  private genAI: GoogleGenerativeAI;

  constructor(private prisma: PrismaService) {
    this.genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || '');
  }

  async analyzeUserMood(userId: string, weekStart: Date) {
    // Get user's time entries for the week
    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekEnd.getDate() + 6);

    const entries = await this.prisma.timeEntry.findMany({
      where: {
        userId,
        date: {
          gte: weekStart,
          lte: weekEnd,
        },
      },
      orderBy: {
        startTime: 'asc',
      },
    });

    // Use Gemini for AI-powered analysis
    const insights = await this.generateGeminiInsights(entries);
    
    // Save insights to database
    await this.prisma.aiInsight.create({
      data: {
        userId,
        weekStart,
        weekEnd,
        summary: insights.summary,
        balanceScore: insights.balanceScore,
        recommendations: insights.recommendations,
      },
    });

    return insights;
  }

  private async generateGeminiInsights(entries: any[]) {
    if (!process.env.GEMINI_API_KEY) {
      return this.fallbackAnalysis(entries);
    }

    try {
      const model = this.genAI.getGenerativeModel({ model: 'gemini-pro' });

      // Prepare user data for analysis
      const userData = this.prepareUserDataForGemini(entries);
      
      const prompt = `
        You are an expert life coach and productivity analyst. Analyze this user's weekly activity data and provide personalized insights.

        User Data:
        ${userData}

        Based on this data, provide:
        1. A brief summary of their week (2-3 sentences)
        2. A work-life balance score (0-100)
        3. 3 specific, actionable recommendations

        Focus on:
        - Sleep patterns and quality
        - Work-life balance
        - Productivity patterns
        - Mental health indicators
        - Areas for improvement

        Respond in JSON format:
        {
          "summary": "...",
          "balanceScore": 85,
          "recommendations": ["...", "...", "..."]
        }
      `;

      const result = await model.generateContent(prompt);
      const response = await result.response;
      const text = response.text();
      
      // Parse JSON response
      const insights = JSON.parse(text.replace(/```json\n?|\n?```/g, ''));
      
      return {
        summary: insights.summary,
        balanceScore: insights.balanceScore,
        recommendations: insights.recommendations,
      };
    } catch (error) {
      console.error('Gemini API error:', error);
      return this.fallbackAnalysis(entries);
    }
  }

  private prepareUserDataForGemini(entries: any[]): string {
    const totalHours = entries.reduce((sum, entry) => sum + entry.durationMinutes / 60, 0);
    const sleepEntries = entries.filter(e => 
      e.category === 'restoration' && e.title.toLowerCase().includes('sleep')
    );
    const productiveEntries = entries.filter(e => e.category === 'productive');
    const leisureEntries = entries.filter(e => e.category === 'leisure');
    
    const avgSleep = sleepEntries.length > 0 
      ? sleepEntries.reduce((sum, e) => sum + e.durationMinutes / 60, 0) / sleepEntries.length 
      : 0;
    
    const productiveHours = productiveEntries.reduce((sum, e) => sum + e.durationMinutes / 60, 0);
    const leisureHours = leisureEntries.reduce((sum, e) => sum + e.durationMinutes / 60, 0);

    return `
Total logged hours: ${totalHours.toFixed(1)}
Average sleep: ${avgSleep.toFixed(1)} hours
Productive hours: ${productiveHours.toFixed(1)}
Leisure hours: ${leisureHours.toFixed(1)}
Work ratio: ${((productiveHours / totalHours) * 100).toFixed(1)}%

Daily breakdown:
${entries.map(entry => `- ${entry.title} (${entry.category}) - ${entry.durationMinutes / 60}h`).join('\n')}
    `.trim();
  }

  private fallbackAnalysis(entries: any[]) {
    const totalHours = entries.reduce((sum, entry) => sum + entry.durationMinutes / 60, 0);
    const avgSleep = this.calculateAverageSleep(entries);
    const productiveHours = entries
      .filter(e => e.category === 'productive')
      .reduce((sum, e) => sum + e.durationMinutes / 60, 0);
    
    const insights = {
      summary: 'Basic analysis completed. AI insights temporarily unavailable.',
      balanceScore: 0,
      recommendations: [] as string[],
    };

    // Sleep analysis
    if (avgSleep < 6) {
      insights.summary += 'Sleep patterns show insufficient rest. ';
      insights.recommendations.push('Consider prioritizing 7-8 hours of sleep for better recovery');
    } else if (avgSleep > 9) {
      insights.summary += 'Sleep duration is higher than average. ';
      insights.recommendations.push('Monitor if extended sleep is affecting daily energy levels');
    }

    // Work-life balance
    const workRatio = productiveHours / totalHours;
    if (workRatio > 0.7) {
      insights.summary += 'High work intensity detected. ';
      insights.recommendations.push('Schedule more leisure and restoration activities');
    } else if (workRatio < 0.3) {
      insights.summary += 'Low productive activity this week. ';
      insights.recommendations.push('Consider setting specific work goals for better focus');
    }

    // Calculate balance score (0-100)
    insights.balanceScore = Math.round(100 - Math.abs(workRatio - 0.5) * 100);

    return insights;
  }

  private calculateAverageSleep(entries: any[]): number {
    // Look for sleep-related entries (restoration category with "sleep" in title)
    const sleepEntries = entries.filter(entry => 
      entry.category === 'restoration' && 
      entry.title.toLowerCase().includes('sleep')
    );
    
    if (sleepEntries.length === 0) return 7; // Default assumption
    
    const totalSleep = sleepEntries.reduce((sum, entry) => sum + entry.durationMinutes / 60, 0);
    return totalSleep / sleepEntries.length;
  }

  async getLatestInsights(userId: string) {
    return this.prisma.aiInsight.findMany({
      where: { userId },
      orderBy: { weekStart: 'desc' },
      take: 4, // Last 4 weeks
    });
  }

  async autoGenerateInsights(userId: string) {
    const now = new Date();
    
    // Generate insights for different time periods if they don't exist
    const timePeriods = [
      { name: 'yesterday', start: new Date(now.getTime() - 24 * 60 * 60 * 1000), end: new Date(now.getTime() - 24 * 60 * 60 * 1000) },
      { name: 'lastWeek', start: this.getStartOfWeek(-1), end: this.getEndOfWeek(-1) },
      { name: 'lastMonth', start: this.getStartOfMonth(-1), end: this.getEndOfMonth(-1) },
    ];

    for (const period of timePeriods) {
      const existing = await this.prisma.aiInsight.findFirst({
        where: {
          userId,
          weekStart: period.start,
        },
      });

      if (!existing) {
        try {
          await this.analyzeUserMood(userId, period.start);
        } catch (error) {
          console.error(`Failed to generate insights for ${period.name}:`, error);
        }
      }
    }
  }

  private getStartOfWeek(weeksOffset: number = 0): Date {
    const now = new Date();
    const startOfWeek = new Date(now);
    startOfWeek.setDate(now.getDate() - now.getDay() + 1 + (weeksOffset * 7)); // Monday
    startOfWeek.setHours(0, 0, 0, 0);
    return startOfWeek;
  }

  private getEndOfWeek(weeksOffset: number = 0): Date {
    const start = this.getStartOfWeek(weeksOffset);
    const end = new Date(start);
    end.setDate(start.getDate() + 6);
    return end;
  }

  private getStartOfMonth(monthsOffset: number = 0): Date {
    const now = new Date();
    const start = new Date(now.getFullYear(), now.getMonth() + monthsOffset, 1);
    return start;
  }

  private getEndOfMonth(monthsOffset: number = 0): Date {
    const now = new Date();
    const end = new Date(now.getFullYear(), now.getMonth() + monthsOffset + 1, 0);
    return end;
  }
}
