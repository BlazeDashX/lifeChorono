import { Controller, Get, Post, Query, Request, UseGuards } from '@nestjs/common';
import { AiInsightsService } from './ai-insights.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@Controller('ai-insights')
@UseGuards(JwtAuthGuard)
export class AiInsightsController {
  constructor(private readonly aiInsightsService: AiInsightsService) {}

  @Get()
  async getInsights(@Request() req) {
    const userId = req.user.sub;
    
    // Auto-generate insights for different time periods if they don't exist
    await this.aiInsightsService.autoGenerateInsights(userId);
    
    return this.aiInsightsService.getLatestInsights(userId);
  }

  @Post('analyze')
  async analyzeWeek(@Request() req, @Query('weekStart') weekStart?: string) {
    const userId = req.user.sub;
    const startOfWeek = weekStart ? new Date(weekStart) : this.getStartOfWeek();
    
    return this.aiInsightsService.analyzeUserMood(userId, startOfWeek);
  }

  private getStartOfWeek(): Date {
    const now = new Date();
    const startOfWeek = new Date(now);
    startOfWeek.setDate(now.getDate() - now.getDay() + 1); // Monday
    startOfWeek.setHours(0, 0, 0, 0);
    return startOfWeek;
  }
}
